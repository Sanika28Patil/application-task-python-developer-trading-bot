import argparse

from bot.client import BinanceFuturesClient
from bot.exceptions import BinanceAPIError, ConfigurationError, ValidationError
from bot.logging_config import setup_logging
from bot.orders import OrderService


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Place MARKET and LIMIT orders on Binance Futures Testnet."
    )
    parser.add_argument("--symbol", required=True, help="Example: BTCUSDT")
    parser.add_argument("--side", required=True, help="BUY or SELL")
    parser.add_argument(
        "--order-type",
        required=True,
        dest="order_type",
        help="MARKET or LIMIT",
    )
    parser.add_argument("--quantity", required=True, help="Order quantity")
    parser.add_argument("--price", help="Required for LIMIT orders")
    return parser


def print_summary(request_data: dict, response_data: dict) -> None:
    print("\nOrder Request Summary")
    print(f"Symbol      : {request_data['symbol']}")
    print(f"Side        : {request_data['side']}")
    print(f"Order Type  : {request_data['order_type']}")
    print(f"Quantity    : {request_data['quantity']}")
    if request_data["price"]:
        print(f"Price       : {request_data['price']}")

    print("\nOrder Response Details")
    print(f"Order ID    : {response_data.get('orderId', 'N/A')}")
    print(f"Status      : {response_data.get('status', 'N/A')}")
    print(f"Executed Qty: {response_data.get('executedQty', 'N/A')}")
    print(f"Avg Price   : {response_data.get('avgPrice', 'N/A')}")
    print("\nResult      : Order placed successfully.")


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    logger = setup_logging()

    try:
        client = BinanceFuturesClient(logger=logger)
        service = OrderService(client)
        request_data, response_data = service.place_order(
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
        )
        print_summary(request_data, response_data)
        return 0
    except ValidationError as exc:
        logger.error("Validation error: %s", exc)
        print(f"Error: {exc}")
        return 1
    except ConfigurationError as exc:
        logger.error("Configuration error: %s", exc)
        print(f"Error: {exc}")
        return 1
    except BinanceAPIError as exc:
        logger.error("Binance API error: %s", exc)
        print(f"Error: {exc}")
        return 1
    except Exception as exc:  # pragma: no cover
        logger.exception("Unexpected error")
        print(f"Unexpected error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
