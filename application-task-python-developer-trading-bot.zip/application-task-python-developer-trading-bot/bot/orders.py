from bot.client import BinanceFuturesClient
from bot.validators import validate_order_input


class OrderService:
    """Handles validation and order payload creation."""

    def __init__(self, client: BinanceFuturesClient) -> None:
        self.client = client

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: str,
        price: str | None = None,
    ) -> tuple[dict, dict]:
        validated = validate_order_input(symbol, side, order_type, quantity, price)

        payload = {
            "symbol": validated["symbol"],
            "side": validated["side"],
            "type": validated["order_type"],
            "quantity": validated["quantity"],
        }

        if validated["order_type"] == "LIMIT":
            payload["price"] = validated["price"]
            payload["timeInForce"] = "GTC"

        response = self.client.place_order(payload)
        return validated, response
