class TradingBotError(Exception):
    """Base exception for the trading bot."""


class ValidationError(TradingBotError):
    """Raised when CLI input is invalid."""


class BinanceAPIError(TradingBotError):
    """Raised when Binance returns an API error."""


class ConfigurationError(TradingBotError):
    """Raised when environment configuration is missing."""
