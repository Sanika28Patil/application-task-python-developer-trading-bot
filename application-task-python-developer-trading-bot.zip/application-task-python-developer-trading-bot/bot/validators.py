from decimal import Decimal, InvalidOperation

from bot.exceptions import ValidationError


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT"}


def normalize_symbol(symbol: str) -> str:
    cleaned = symbol.strip().upper()
    if not cleaned:
        raise ValidationError("Symbol is required.")
    return cleaned


def normalize_side(side: str) -> str:
    cleaned = side.strip().upper()
    if cleaned not in VALID_SIDES:
        raise ValidationError("Side must be BUY or SELL.")
    return cleaned


def normalize_order_type(order_type: str) -> str:
    cleaned = order_type.strip().upper()
    if cleaned not in VALID_ORDER_TYPES:
        raise ValidationError("Order type must be MARKET or LIMIT.")
    return cleaned


def validate_positive_number(value: str, field_name: str) -> str:
    try:
        decimal_value = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValidationError(f"{field_name} must be a valid number.") from None

    if decimal_value <= 0:
        raise ValidationError(f"{field_name} must be greater than 0.")

    return format(decimal_value.normalize(), "f")


def validate_order_input(
    symbol: str,
    side: str,
    order_type: str,
    quantity: str,
    price: str | None,
) -> dict:
    normalized_symbol = normalize_symbol(symbol)
    normalized_side = normalize_side(side)
    normalized_order_type = normalize_order_type(order_type)
    normalized_quantity = validate_positive_number(quantity, "Quantity")

    normalized_price = None
    if normalized_order_type == "LIMIT":
        if price is None:
            raise ValidationError("Price is required for LIMIT orders.")
        normalized_price = validate_positive_number(price, "Price")

    return {
        "symbol": normalized_symbol,
        "side": normalized_side,
        "order_type": normalized_order_type,
        "quantity": normalized_quantity,
        "price": normalized_price,
    }
