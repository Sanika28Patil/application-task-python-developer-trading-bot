import hashlib
import hmac
import os
import time
from urllib.parse import urlencode

import requests
from dotenv import load_dotenv

from bot.exceptions import BinanceAPIError, ConfigurationError


class BinanceFuturesClient:
    """Small wrapper around Binance Futures Testnet REST API."""

    def __init__(self, logger, timeout: int = 15) -> None:
        load_dotenv()

        self.api_key = os.getenv("BINANCE_API_KEY")
        self.api_secret = os.getenv("BINANCE_API_SECRET")
        self.base_url = os.getenv(
            "BINANCE_BASE_URL", "https://testnet.binancefuture.com"
        )
        self.timeout = timeout
        self.logger = logger

        if not self.api_key or not self.api_secret:
            raise ConfigurationError(
                "Missing BINANCE_API_KEY or BINANCE_API_SECRET in environment."
            )

        self.session = requests.Session()
        self.session.headers.update({"X-MBX-APIKEY": self.api_key})

    def _sign_params(self, params: dict) -> str:
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return f"{query_string}&signature={signature}"

    def place_order(self, params: dict) -> dict:
        endpoint = "/fapi/v1/order"
        url = f"{self.base_url}{endpoint}"

        request_params = {
            **params,
            "timestamp": int(time.time() * 1000),
            "recvWindow": 5000,
        }

        signed_query = self._sign_params(request_params)

        safe_log_params = request_params.copy()
        self.logger.info("Sending POST %s with params=%s", endpoint, safe_log_params)

        try:
            response = self.session.post(
                url,
                params=signed_query,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            self.logger.exception("Network error while calling Binance API")
            raise BinanceAPIError(f"Network error: {exc}") from exc

        try:
            response_data = response.json()
        except ValueError as exc:
            self.logger.exception("Could not parse Binance API response")
            raise BinanceAPIError("Received non-JSON response from Binance.") from exc

        self.logger.info(
            "Received response status=%s body=%s",
            response.status_code,
            response_data,
        )

        if response.status_code >= 400:
            error_message = response_data.get("msg", "Unknown Binance API error.")
            raise BinanceAPIError(
                f"Binance API error ({response.status_code}): {error_message}"
            )

        return response_data
