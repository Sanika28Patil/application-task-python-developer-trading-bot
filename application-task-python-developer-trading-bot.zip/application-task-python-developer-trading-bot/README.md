# Binance Futures Testnet Trading Bot

This project is a small Python CLI application that places `MARKET` and `LIMIT` orders on Binance Futures Testnet (USDT-M).

## Features

- Place `BUY` and `SELL` orders
- Support `MARKET` and `LIMIT` order types
- Validate CLI input before calling the API
- Log requests, responses, and errors to a file
- Keep the code split into CLI, service, validation, and API client layers

## Project Structure

```text
trading_bot/
  bot/
    __init__.py
    client.py
    exceptions.py
    logging_config.py
    orders.py
    validators.py
  cli.py
  README.md
  requirements.txt
```

## Setup

1. Create and activate a Python virtual environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Copy `.env.example` to `.env`
4. Add your Binance Futures Testnet API key and secret in `.env`

Example:

```env
BINANCE_API_KEY=your_testnet_api_key
BINANCE_API_SECRET=your_testnet_api_secret
BINANCE_BASE_URL=https://testnet.binancefuture.com
```

## How to Run

### MARKET order example

```bash
python cli.py --symbol BTCUSDT --side BUY --order-type MARKET --quantity 0.001
```

### LIMIT order example

```bash
python cli.py --symbol BTCUSDT --side SELL --order-type LIMIT --quantity 0.001 --price 80000
```

## Output

The CLI prints:

- Order request summary
- Order response details
- Success or error message

Logs are written to:

```text
logs/trading_bot.log
```

## Assumptions

- This app is only for Binance Futures Testnet USDT-M
- `price` is required only for `LIMIT` orders
- `avgPrice` may be `0.00000` or unavailable depending on order execution state
- API credentials are loaded from environment variables for security

## Deliverables Checklist

- Source code
- `README.md`
- `requirements.txt`
- Log file with at least one `MARKET` order
- Log file with at least one `LIMIT` order
